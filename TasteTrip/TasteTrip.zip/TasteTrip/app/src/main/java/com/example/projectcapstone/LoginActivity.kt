package com.example.projectcapstone

import android.content.Intent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.activity.ComponentActivity
import com.example.projectcapstone.MainActivity

class LoginActivity : ComponentActivity(), View.OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val LBtn1: TextView = findViewById(R.id.L_btn_1)
        LBtn1.setOnClickListener(this)

        val txtSignup: TextView = findViewById(R.id.txt_signup)
        txtSignup.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.L_btn_1 -> {
                val moveIntent = Intent(this@LoginActivity, MenuActivity::class.java)
                startActivity(moveIntent)
            }
            R.id.txt_signup -> {
                val moveIntent = Intent(this@LoginActivity, RegisterActivity::class.java)
                startActivity(moveIntent)
            }
        }
    }
}
